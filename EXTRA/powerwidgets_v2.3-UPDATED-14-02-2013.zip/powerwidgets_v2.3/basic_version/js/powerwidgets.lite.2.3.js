/*
 * ************************************************************* *
 * Name       : Power Widgets lite version                       *
 * Date       : May 2012                                         *
 * Owner      : CreativeMilk                                     *
 * Url        : www.creativemilk.net                             *
 * Version    : 2.3                                              *
 * Updated    : 14/02/2013                                       *
 * Developer  : Mark                                             *
 * Dependency : jQuery UI core, json2(ie7)                       *
 * Lib        : jQuery 1.7+                                      *
 * Licence    : http://codecanyon.net/item/power-widgets-manage-and-display-your-content/2901689
 * ************************************************************* *   
 */

;(function($, window, document, undefined){
	
	//"use strict"; // jshint ;_;
	
	var pluginName = 'powerWidgetsLite';
	
	function Plugin(element, options){
		/**
		* Variables.
		**/			
		this.obj         = $(element);
		this.o           = $.extend({}, $.fn[pluginName].defaults, options);
		this.objId       = this.obj.attr('id');
		this.pwCtrls     = '.powerwidget-ctrls'
		this.widget      = this.obj.find(this.o.widgets);
		this.toggleClass = this.o.toggleClass.split('|');
		
		this.init();
	};

	Plugin.prototype = {
	
		/**	
		* Important settings like storage and touch support. 
		* 
		* @param:
		**/	
		_settings: function(){
			
            var self = this;
				
			//*****************************************************************//
			//////////////////////// LOCALSTORAGE CHECK /////////////////////////
			//*****************************************************************//
					
				  storage = !!function() {
				  var result,
					  uid = +new Date;
				  try {
					localStorage.setItem(uid, uid);
					result = localStorage.getItem(uid) == uid;
					localStorage.removeItem(uid);
					return result;
				  } catch(e) {}
				}() && localStorage;
				
			//*****************************************************************//
			/////////////////////////// SET/GET KEYS ////////////////////////////
			//*****************************************************************//
			
				if(storage && self.o.localStorage){  
					keySettings    = 'Plugin_settings_'+location.pathname+'_'+self.objId;
					getKeySettings = localStorage.getItem(keySettings);
						
					keyPosition    = 'Plugin_position_'+location.pathname+'_'+self.objId;
					getKeyPosition = localStorage.getItem(keyPosition);
				}	
		
			//*****************************************************************//
			////////////////////////// TOUCH SUPPORT ////////////////////////////
			//*****************************************************************//
			
				/**
				* Check for touch support and set right click events.
				**/
				if(('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch){
					clickEvent = 'click tap';	
				}else{
					clickEvent = 'click';	
				}
			
			},

			/**
			* Function for the indicator image.
			* 
			* @param:
			**/
			_runLoaderWidget: function(elm){
				var self = this;
				if(self.o.indicator === true){
				  elm
				  .parents(self.o.widgets)
				  .find('.powerwidget-loader')
				  .stop(true, true)
				  .fadeIn(100)
				  .delay(self.o.indicatorTime)
				  .fadeOut(100);	
				}
			},	
			
			/**
			* Save all settings to the localStorage. 
			* 
			* @param: 
			**/	
			_saveSettingsWidget: function(){
				
				var self = this;
				
				self._settings();
				
				if(storage && self.o.localStorage){ 
					var storeSettings = [];
					
					self.obj.find(self.o.widgets).each(function(){
						var storeSettingsStr          = {};
						storeSettingsStr['id']        = $(this).attr('id');
						storeSettingsStr['title']     = $(this).children('header').children('h2').text();
						storeSettingsStr['hidden']    = ($(this).is(':hidden') ? 1 : 0);
						storeSettingsStr['collapsed'] = ($(this).hasClass('powerwidget-collapsed') ? 1 : 0);
						storeSettings.push(storeSettingsStr);
					});	
						
					var storeSettingsObj = JSON.stringify( {'widget':storeSettings} );
	
					/* Place it in the storage(only if needed) */
					if(getKeySettings != storeSettingsObj){
						localStorage.setItem(keySettings, storeSettingsObj); 
					}
				}
				
				/**	
				* Run the callback function.
				**/	
				if(typeof self.o.onSave == 'function'){
					self.o.onSave.call(this);
				}	
			},
					
			/**	
			* Save positions to the localStorage. 
			* 
			* @param: 
			**/	
			_savePositionWidget: function(){
				
				var self = this;
				
				self._settings();
				
				if(storage && self.o.localStorage){ 
					var mainArr = [];
					
					self.obj.find(self.o.grid+'.sortable-grid').each(function(){
						var subArr = [];
						$(this).children(self.o.widgets).each(function(){
							var subObj   = {};
							subObj['id'] = $(this).attr('id');
							subArr.push(subObj);
						});
						var out = {'section':subArr}
						mainArr.push(out);
					});	
						
					var storePositionObj = JSON.stringify( {'grid':mainArr} );
	
					/* Place it in the storage(only if needed) */
					if(getKeyPosition != storePositionObj){
						localStorage.setItem(keyPosition, storePositionObj); 
					}
				}
				
				/**	
				* Run the callback function.
				**/	
				if(typeof self.o.onSave == 'function'){
					self.o.onSave.call(this);
				}	
			},
			
			/**	
			* Code that we run at the start. 
			* 
			* @param:
			**/	
			init: function(){
				
				var self = this;
				
				self._settings();
	
				/**
				* Force users to use an id(it's needed for the local storage).
				**/
				if(!$('#'+self.objId).length){
					alert('It looks like your using a class instead of an ID, dont do that!')	
				}
				
				/**
				* Add RTL support.
				**/
				if(self.o.rtl === true){
					$('body').addClass('rtl');
				}
				
				/**
				* This will add an extra class that we use to store the
				* widgets in the right order.(savety)
				**/
	
				$(self.o.grid).each(function(){
					if($(this).find(self.o.widgets).length){
						$(this).addClass('sortable-grid');	
					}
				});
						
			//*****************************************************************//
			//////////////////////// SET POSITION WIDGET ////////////////////////
			//*****************************************************************//						
					   
				/**	
				* Run if data is present.
				**/
				if(storage && self.o.localStorage && getKeyPosition){
						
					var jsonPosition = JSON.parse(getKeyPosition);
					
					/**	
					* Loop the data, and put every widget on the right place.
					**/	
					for(var key in jsonPosition.grid){
						var changeOrder = self.obj.find(self.o.grid+'.sortable-grid').eq(key);
						 for(var key2 in jsonPosition.grid[key].section){								
							changeOrder.append($('#'+jsonPosition.grid[key].section[key2].id));
						}
					}
			
				}
	
			//*****************************************************************//
			/////////////////////// SET SETTINGS WIDGET /////////////////////////
			//*****************************************************************//						
	  
				/**	
				* Run if data is present.
				**/
				if(storage && self.o.localStorage && getKeySettings){
						
					var jsonSettings = JSON.parse(getKeySettings);
					
					/**	
					* Loop the data and hide/show the widgets and set the inputs in
					* panel to checked(if hidden) and add an indicator class to the div.
					* Loop all labels and update the widget titles.
					**/			
					for(var key in jsonSettings.widget){
						var widgetId = $('#'+jsonSettings.widget[key].id);
												
						/**	
						* Hide/show widget.
						**/			
						if(jsonSettings.widget[key].hidden == 1){
							widgetId.hide(1);
						}else{
							widgetId
							.show(1)
							.removeAttr('data-widget-hidden');				
						}
						
						/**	
						* Toggle content widget.
						**/	
						if(jsonSettings.widget[key].collapsed == 1){
							widgetId
							.addClass('powerwidget-collapsed')
							.children('div')
							.hide(1);
						}
						
						/**	
						* Update title widget (if needed).
						**/	
						if(widgetId.children('header').children('h2').text() != jsonSettings.widget[key].title){	
							widgetId
							.children('header')
							.children('h2')
							.text(jsonSettings.widget[key].title);
						}	
					}
				}
				
			//*****************************************************************//
			////////////////////////// LOOP AL WIDGETS //////////////////////////
			//*****************************************************************//
				
				/**
				* This will add/edit/remove the settings to all widgets
				**/
				self.widget.each(function(){
					
					var tWidget    = $(this);
					var thisHeader = $(this).children('header');
			  
					/**
					* Dont double wrap(check).
					**/
					if(!thisHeader.parent().attr('role')){
					
						/**
						* Hide the widget if the dataset 'widget-hidden' is set to true.
						**/
						if(tWidget.data('widget-hidden') === true){
							tWidget.hide();
						}
											
						/**
						* Hide the content of the widget if the dataset 
						* 'widget-collapsed' is set to true.
						**/
						if(tWidget.data('widget-collapsed') === true){
							tWidget
							.addClass('powerwidget-collapsed')
							.children('div')
							.hide();
						}
					
						/**
						* Check for the dataset 'widget-icon' if so get the icon 
						* and attach it to the widget header.
						**/
						if(tWidget.data('widget-icon')){						
							thisHeader.prepend('<i class="powerwidget-icon '+tWidget.data('widget-icon')+'"></i>');
						}						
																					
						/**
						* Add a toggle button to the widget header (if set to true).
						**/
						if(self.o.toggleButton === true && tWidget.data('widget-togglebutton') === undefined){	
							if(tWidget.data('widget-collapsed') === true || tWidget.hasClass('powerwidget-collapsed')){
								var toggleSettings = self.toggleClass[1];
							}else{
									toggleSettings = self.toggleClass[0];
							}
							thisHeader.append('<div class="powerwidget-ctrls"><a href="javascript:void(0)" class="button-icon powerwidget-toggle-btn"><i class="'+toggleSettings+'"></i></a></div>');
						}
					
						/**
						* Adding a helper class to all sortable widgets, this will be 
						* used to find the widgets that are sortable, it will skip the widgets 
						* that have the dataset 'widget-sortable="false"' set to false.
						**/
						if(self.o.sortable === true && tWidget.data('widget-sortable') === undefined){
							tWidget.addClass('powerwidget-sortable');
						}
										
						/**
						* If the edit box is present copy the title to the input.
						**/
						if(tWidget.find(self.o.editPlaceholder).length){
							tWidget
							.find(self.o.editPlaceholder)
							.find('input')
							.val(thisHeader.children('h2').text());	
						}
		
						/**
						* Prepend the image to the widget header.
						**/
						thisHeader.append('<span class="powerwidget-loader"></span>');
				
						/**
						* Adding roles to some parts.
						**/
						tWidget
						.attr('role','widget')
						.children('div')
						.attr('role','content')
						.prev('header')
						.attr('role','heading')
						.children('div')
						.attr('role','menu');						
					}
				});
				
				/**
				* Hide all buttons if option is set to true.
				**/
				if(self.o.buttonsHidden === true){
					$(self.o.pwCtrls).hide();
				}
	
			//******************************************************************//
			////////////////////////////// SORTABLE //////////////////////////////
			//******************************************************************//
	
				/**
				* jQuery UI soratble, this allows users to sort the widgets. 
				* Notice that this part needs the jquery-ui core to work.
				**/
				if(self.o.sortable === true && jQuery.ui){
					var sortItem = self.obj.find('.sortable-grid').not('[data-widget-excludegrid]');
					sortItem.sortable({
						items:                sortItem.find('.powerwidget-sortable'),
						connectWith:          sortItem,
						placeholder:          self.o.placeholderClass,
						cursor:               'move',
						revert:               true, 
						opacity:              self.o.opacity,
						delay:                200,
						cancel:               '.button-icon, #powerwidget-fullscreen-mode > div',
						zIndex:               10000,
						handle:               self.o.dragHandle,
						forcePlaceholderSize: true,
						forceHelperSize:      true,
						update: function(event, ui){
							/* run pre-loader in the widget */
							self._runLoaderWidget(ui.item.children());	
							/* store the positions of the plugins */
							self._savePositionWidget();
							/**	
							* Run the callback function.
							**/	
							if(typeof self.o.onChange == 'function'){
								self.o.onChange.call(this, ui.item);
							}								
						}
					});	
				}
	
			//*****************************************************************//
			////////////////////////// BUTTONS VISIBLE //////////////////////////
			//*****************************************************************//
				
				/**
				* Show and hide the widget control buttons, the buttons will be 
				* visible if the users hover over the widgets header. At default the 
				* buttons are always visible.
				**/
				if(self.o.buttonsHidden === true){
											
					/**
					* Show and hide the buttons.
					**/
					self.widget.children('header').hover(function(){
						$(this)
						.children(self.o.pwCtrls)
						.stop(true, true)
						.fadeTo(100,1.0);
					},function(){
						$(this)
						.children(self.o.pwCtrls)
						.stop(true, true)
						.fadeTo(100,0.0);		
					});
				}	
		

			//*****************************************************************//
			///////////////////////// CLICKEVENTS //////////////////////////
			//*****************************************************************//	
			
				this._clickEvents();
	
			//*****************************************************************//
			///////////////////// DELETE LOCAL STORAGE KEYS /////////////////////
			//*****************************************************************//	
	
				/**	
				* Delete the settings key.
				**/
				$(self.o.deleteSettingsKey).on(clickEvent, this, function(e){
					if(storage && self.o.localStorage){
						var cleared = confirm(self.o.settingsKeyLabel);
						if(cleared){ 					
							localStorage.removeItem(keySettings);
						}
					}
					e.preventDefault();		
				});
				
				/**	
				* Delete the position key.
				**/
				$(self.o.deletePositionKey).on(clickEvent, this, function(e){
					if(storage && self.o.localStorage){
						var cleared = confirm(self.o.positionKeyLabel);
						if(cleared){ 					
							localStorage.removeItem(keyPosition);
						}
					}
					e.preventDefault();		
				});	
	
			//*****************************************************************//
			///////////////////////// CREATE NEW KEYS  //////////////////////////
			//*****************************************************************//	
			
				/**
				* Create new keys if non are present.
				**/
				if(storage && self.o.localStorage){ 
				
					/**
					* If the local storage key (keySettings) is empty or 
					* does not excite, create one and fill it.
					**/	
					if(getKeySettings === null || getKeySettings.length < 1){
						self._saveSettingsWidget();					
					}
	
					/**
					* If the local storage key (keyPosition) is empty or 
					* does not excite, create one and fill it.
					**/		
					if(getKeyPosition === null || getKeyPosition.length < 1){					
						self._savePositionWidget();					
					}
				}
						
		},

		/**
		* All of the click events.
		*
		* @param:
		**/
		_clickEvents: function(){
			
			var self = this;
			
			self._settings();
	
			//*****************************************************************//
			/////////////////////////// TOGGLE WIDGETS //////////////////////////
			//*****************************************************************//
				
				/**
				* Allow users to toggle the content of the widgets.
				**/
				self.widget.on(clickEvent, '.powerwidget-toggle-btn', function(e){
					
					var tWidget = $(this);
					var pWidget = tWidget.parents(self.o.widgets);
	
					/**						
					* Run function for the indicator image.
					**/
					self._runLoaderWidget(tWidget);
			
					/**
					* Change the class and hide/show the widgets content.
					**/ 	
					if(pWidget.hasClass('powerwidget-collapsed')){
						tWidget
						.children()
						.removeClass(self.toggleClass[1])
						.addClass(self.toggleClass[0])							
						.parents(self.o.widgets)
						.removeClass('powerwidget-collapsed')
						.children('[role=content]')
						.slideDown(self.o.toggleSpeed, function(){
							self._saveSettingsWidget();
						});
					}else{
						tWidget
						.children()
						.removeClass(self.toggleClass[0])
						.addClass(self.toggleClass[1])
						.parents(self.o.widgets)
						.addClass('powerwidget-collapsed')
						.children('[role=content]')
						.slideUp(self.o.toggleSpeed, function(){
							self._saveSettingsWidget();
						});
					}
					
					/**	
					* Run the callback function.
					**/	
					if(typeof self.o.onToggle == 'function'){
						self.o.onToggle.call(this, pWidget);
					}
				
					e.preventDefault();
				});	
        },
		
		/**
		* Destroy.
		*
		* @param:
		**/
		destroy: function(){
            var self = this;
			self.widget.off('click',self._clickEvents());
			self.obj.removeData(pluginName);		
		}
	};

	$.fn[pluginName] = function(option) {
  		return this.each(function() {
			var $this   = $(this);
            var data    = $this.data(pluginName);
            var options = typeof option == 'object' && option;
			if (!data){ 
			  $this.data(pluginName, (data = new Plugin(this, options)))
			}
			if (typeof option == 'string'){
				 data[option]();
			}
		});
	};
	
	/**
	* Default settings(dont change).
	* You can globally override these options
	* by using $.fn.pluginName.key = 'value';
	**/
	$.fn[pluginName].defaults = {
		grid: 'section',
		widgets: '.powerwidget',
		localStorage: true,
		deleteSettingsKey: '',
		settingsKeyLabel: 'Reset settings?',
		deletePositionKey: '',
		positionKeyLabel: 'Reset position?',			
		sortable: true,
		buttonsHidden: false,
		toggleButton: true,
		toggleClass: 'min-10 | plus-10',
		toggleSpeed: 200,
		onToggle: function(){},
		opacity: 1.0,
		dragHandle: '> header',
		placeholderClass: 'powerwidget-placeholder',
		indicator: true,
		indicatorTime: 600,
		rtl: false,
		onChange: function(){},
		onSave: function(){}		
	};


})(jQuery, window, document);