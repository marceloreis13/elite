<div class="inner-spacer">  
<!-- dummy file -->
<p>data-widget-refreshbutton="false"</p>
<div class="spacer-10"></div>
<div class="powerwidget-timestamp"></div>
</div>

