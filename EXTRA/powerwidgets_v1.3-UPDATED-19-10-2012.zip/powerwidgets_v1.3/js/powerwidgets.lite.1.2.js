/*
 * ************************************************************* *
 * Name       : Power Widgets tiny version                       *
 * Date       : May 2012                                         *
 * Owner      : CreativeMilk                                     *
 * Url        : www.creativemilk.net                             *
 * Version    : 1.2                                              *
 * Updated    : 19/10/2012                                       *
 * Developer  : Mark                                             *
 * Dependency : jQuery UI core, json2(ie7)                       *
 * Lib        : jQuery 1.7+                                      *
 * Licence    : http://codecanyon.net/item/power-widgets-manage-and-display-your-content/2901689
 * ************************************************************* *
 */

// Note: we have used .attr() instead of .data() for some parts, 
// as the .data() will not work propper(1.7.2 core bug?).

;(function($, window, document, undefined){
    $.fn.powerWidgetsLite = function(options) { 
	
		options = $.extend({}, $.fn.powerWidgetsLite.options, options); 
	 
			return this.each(function() {  
				
				/**
				* Variables.
				**/
				var obj                 = $(this);
				var objId               = obj.attr('id');
				var pwCtrls             = '.powerwidget-ctrls'
				var widget              = obj.find(options.widgets);
				var widgetHeader        = obj.find(options.widgets+' > header');
				var o_widgetClass       = options.widgets;
				var o_grid              = options.grid;
				var o_localStorage      = options.localStorage;
				var o_deleteSettingsKey = options.deleteSettingsKey;
				var o_settingsKeyLabel  = options.settingsKeyLabel;
				var o_deletePositionKey = options.deletePositionKey;
				var o_positionKeyLabel  = options.positionKeyLabel;
				var o_allowSortable     = options.sortable;
				var o_buttonsHidden     = options.buttonsHidden;
				var o_indicator         = options.indicator;
				var o_indicatorTime     = options.indicatorTime;
				var o_toggleSpeed       = options.toggleSpeed;
				var o_placeholderClass  = options.placeholderClass;
				var o_opacity           = options.opacity;
				var o_dragHandle        = options.dragHandle;
				var o_toggleClass       = options.toggleClass.split('|');
				var o_allowToggle       = options.toggleButton;
				var o_rtl               = options.rtl;
				
				//*****************************************************************//
				//////////////////////// LOCALSTORAGE CHECK /////////////////////////
				//*****************************************************************//

					var storage,
						fail,
						uid;
					try{
					  uid      = new Date;
					  (storage = window.localStorage).setItem(uid, uid);
					  fail     = storage.getItem(uid) != uid;
					  storage.removeItem(uid);
					  fail && (storage = false);
					}catch(e){}	
							
				//*****************************************************************//
				/////////////////////////// SET/GET KEYS ////////////////////////////
				//*****************************************************************//
					
					if(storage && o_localStorage){  
						var keySettings    = 'powerwidgets_settings_'+location.pathname+'_'+objId;
						var getKeySettings = localStorage.getItem(keySettings);
							
						var keyPosition    = 'powerwidgets_position_'+location.pathname+'_'+objId;
						var getKeyPosition = localStorage.getItem(keyPosition);
					}
				
				//*****************************************************************//
				/////////////////////////////// INIT ////////////////////////////////
				//*****************************************************************//
		
					/**
					* Force users to use an id(it's needed for the local storage).
					**/
				    if(!objId.length){
						alert('It looks like your using a class instead of an ID, dont do that!')	
					}
					
					/**
					* Add RTL support.
					**/
					if(o_rtl === true){
						$('body').addClass('rtl');
					}
					
					/**
					* This will add an extra class that we use to store the
					* widgets in the right order.(savety)
					**/
					$(o_grid).each(function(){
						if($(this).children(o_widgetClass).length){
							$(this).addClass('sortable-grid');	
						}
					});

					/**
					* Check for touch support and set right click events.
					**/
					if(('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch){
						var clickEvent = 'click tap';	
					}else{
						var clickEvent = 'click';	
					}
					
				//*****************************************************************//
				///////////////////////// CREATE NEW KEYS  //////////////////////////
				//*****************************************************************//	
				
					/**
					* Create new keys if non are present.
					**/
                    if(storage && o_localStorage){ 
					
						/**
						* If the local storage key (keySettings) is empty or 
						* does not excite, create one and fill it.
						**/	
						if(getKeySettings === null || getKeySettings.length < 1){
							saveSettingsWidget();					
						}
	
						/**
						* If the local storage key (keyPosition) is empty or 
						* does not excite, create one and fill it.
						**/		
						if(getKeyPosition === null || getKeyPosition.length < 1){					
							savePositionWidget();					
						}
					}

				//*****************************************************************//
				//////////////////////// SET POSITION WIDGET ////////////////////////
				//*****************************************************************//						
						   
					/**	
					* Run if data is present.
					**/
					if(storage && o_localStorage && getKeyPosition){
							
						var jsonPosition = JSON.parse(getKeyPosition);
						
						/**	
						* Loop the data, and put every widget on the right place.
						**/	
						for(var key in jsonPosition.grid){
							var changeOrder = obj.find(o_grid+'.sortable-grid').eq(key);
							 for(var key2 in jsonPosition.grid[key].section){								
								changeOrder.append($('#'+jsonPosition.grid[key].section[key2].id));
							}
						}
					}

				//*****************************************************************//
				/////////////////////// SET SETTINGS WIDGET /////////////////////////
				//*****************************************************************//						
		   
					/**	
					* Run if data is present.
					**/
					if(storage && o_localStorage && getKeySettings){
							
						var jsonSettings = JSON.parse(getKeySettings);
						
						/**	
						* Loop the data and hide/show the widgets and set the inputs in
						* panel to checked(if hidden) and add an indicator class to the div.
						* Loop all labels and update the widget titles.
						**/			
						for(var key in jsonSettings.widget){
							var widgetId = $('#'+jsonSettings.widget[key].id);
															
							/**	
							* Hide/show widget.
							**/			
							if(jsonSettings.widget[key].hidden == 1){
								widgetId.hide(1);
							}else{
								widgetId.show(1).removeAttr('data-widget-hidden');				
							}
							
							/**	
							* Toggle content widget.
							**/	
							if(jsonSettings.widget[key].collapsed == 1){
								widgetId
								.addClass('powerwidget-collapsed')
								.children('div')
								.hide(1);
							}
							
							/**	
							* Update title widget (if needed).
							**/	
							if(widgetId.children('header').children('h2').text() != jsonSettings.widget[key].title){	
								widgetId
								.children('header')
								.children('h2')
								.text(jsonSettings.widget[key].title);
							}	
						}
					}
					
				//*****************************************************************//
				////////////////////////// LOOP AL WIDGETS //////////////////////////
				//*****************************************************************//
					
					/**
					* This will add/edit/remove the settings to all widgets
					**/
					widget.each(function(){
						
						var thisHeader = $(this).children('header');
						
						/**
						* Hide the widget if the dataset 'widget-hidden' is set to true.
						**/
						if($(this).data('widget-hidden') === true){
							$(this).hide();
						}	
										
						/**
						* Hide the content of the widget if the dataset 
						* 'widget-collapsed' is set to true.
						**/
						if($(this).data('widget-collapsed') === true){
							$(this)
							.addClass('powerwidget-collapsed')
							.children('div')
							.hide();
						}
											
						/**
						* Check for the dataset 'widget-icon' if so get the icon 
						* and attach it to the widget header.
						**/
						if($(this).data('widget-icon')){						
							thisHeader
							.prepend('<span class="powerwidget-icon"/>')
							.children()
							.addClass($(this).data('widget-icon'));
						}
																												
						/**
						* Add a toggle button to the widget header.
						**/	
						if(o_allowToggle == true){				
							if($(this).data('widget-collapsed') === true || $(this).hasClass('powerwidget-collapsed')){
								var toggleSettings = o_toggleClass[1];
							}else{
									toggleSettings = o_toggleClass[0];
							}
							thisHeader.append('<div class="powerwidget-ctrls"><a href="javascript:void(0)" class="button-icon powerwidget-toggle-btn"><span class="'+toggleSettings+'"></span></a></div>');
						}
						/**
						* Adding a helper class to all sortable widgets, this will be 
						* used to find the widgets that are sortable, it will skip the widgets 
						* that have the dataset 'widget-sortable="false"' set to false.
						**/
						if(o_allowSortable === true && $(this).data('widget-sortable') === undefined){
							$(this).addClass('powerwidget-sortable');
						}
						
						/**
						* Adding roles to some parts.
						**/
						$(this)
						.attr('role','widget')
						.children('div')
						.attr('role','content')
						.prev('header')
						.attr('role','heading')
						.children('div')
						.attr('role','menu');
					});
					
				//*****************************************************************//
				////////////////////////// BUTTONS VISIBLE //////////////////////////
				//*****************************************************************//
	
					/**
					* Show and hide the widget control buttons, the buttons will be 
					* visible if the users hover over the widgets header. At default the 
					* buttons are always visible.
					**/
					if(o_buttonsHidden === true){
						
						/**
						* Hide all buttons.
						**/
						$(pwCtrls).hide();
						
						/**
						* Show and hide the buttons.
						**/
						widgetHeader.hover(function(){
							$(this)
							.children(pwCtrls)
							.stop(true, true)
							.fadeTo(100,1.0);
						},function(){
							$(this)
							.children(pwCtrls)
							.stop(true, true)
							.fadeTo(100,0.0);		
						});
					}

				//*****************************************************************//
				///////////////////////// PRELOADER FUNCTION ////////////////////////
				//*****************************************************************//
				
					/**
					* Prepend the image to the widget header.
					**/
					widgetHeader.append('<span class="powerwidget-loader"/>');
					
					/**
					* Function for the indicator image.
					**/
					function runLoaderWidget(elm){
						if(o_indicator === true){
						  elm
						  .parents(o_widgetClass)
						  .find('.powerwidget-loader')
						  .stop(true, true)
						  .fadeIn(100)
						  .delay(o_indicatorTime)
						  .fadeOut(100);	
						}
					}

				//*****************************************************************//
				/////////////////////////// TOGGLE WIDGETS //////////////////////////
				//*****************************************************************//
								 
					/**
					* Allow users to toggle the content of the widgets.
					**/
					widget.on(clickEvent, '.powerwidget-toggle-btn', function(e){
						
						/**						
						* Run function for the indicator image.
						**/
						runLoaderWidget($(this));

						/**
						* Change the class and hide/show the widgets content.
						**/ 	
						if($(this).parents(o_widgetClass).hasClass('powerwidget-collapsed')){
							$(this)
							.children()
							.removeClass(o_toggleClass[1])
							.addClass(o_toggleClass[0])							
							.parents(o_widgetClass)
							.removeClass('powerwidget-collapsed')
							.children('div:first')
							.slideDown(o_toggleSpeed, function(){
								saveSettingsWidget();
							});
						}else{
							$(this)
							.children()
							.removeClass(o_toggleClass[0])
							.addClass(o_toggleClass[1])
							.parents(o_widgetClass)
							.addClass('powerwidget-collapsed')
							.children('div:first')
							.slideUp(o_toggleSpeed, function(){
								saveSettingsWidget();
							});
						}
						
						/**	
						* Run the callback function.
						**/	
						if(typeof options.onToggle == 'function'){
							options.onToggle.call(this);
						}
					
						e.preventDefault();
					});
											
				//******************************************************************//
				////////////////////////////// SORTABLE //////////////////////////////
				//******************************************************************//
		
					/**
					* jQuery UI soratble, this allows users to sort the widgets. 
					* Notice that this part needs the jquery-ui core to work.
					**/
					if(o_allowSortable === true){
						var sortItem = obj.find('.sortable-grid').not('[data-widget-excludegrid]');
						
						sortItem.sortable({
							items:                sortItem.find('.powerwidget-sortable'),
							connectWith:          sortItem,
							placeholder:          o_placeholderClass,
							cursor:               'move',
							revert:               true, 
							opacity:              o_opacity,
							delay:                200,
							cancel:               '.button-icon',
							zIndex:               10000,
							handle:               o_dragHandle,
							forcePlaceholderSize: true,
							forceHelperSize:      true,
							stop: function(event, ui){
								/* run pre-loader in the widget */
								runLoaderWidget(ui.item.children());	
								/* store the positions of the plugins */
								savePositionWidget();
							}
						});	
					}
	
				//*****************************************************************//
				/////////////////// SAVE SETTINGS WIDGET FUNCTION ///////////////////
				//*****************************************************************//		
					
					/**	
					* Function to save the stettings of the widgets.
					**/
					function saveSettingsWidget(){	
						if(storage && o_localStorage){ 
							var storeSettings = [];
							
							obj.find(o_widgetClass).each(function(){
								var storeSettingsStr          = {};
								storeSettingsStr['id']        = $(this).attr('id');
								storeSettingsStr['style']     = $(this).attr('data-widget-attstyle');
								storeSettingsStr['title']     = $(this).children('header').children('h2').text();
								storeSettingsStr['hidden']    = ($(this).is(':hidden') ? 1 : 0);
								storeSettingsStr['collapsed'] = ($(this).hasClass('powerwidget-collapsed') ? 1 : 0);
								storeSettings.push(storeSettingsStr);
							});	
								
							var storeSettingsObj = JSON.stringify( {'widget':storeSettings} );
		
							/* Place it in the storage(only if needed) */
							if(getKeySettings != storeSettingsObj){
								localStorage.setItem(keySettings, storeSettingsObj); 
							}
						}
					}
									
				//*****************************************************************//
				/////////////////// SAVE POSITION WIDGET FUNCTION ///////////////////
				//*****************************************************************//
								
					/**	
					* Function to save the positions of the widgets.
					**/
					function savePositionWidget(){
						if(storage && o_localStorage){ 
							var mainArr = [];
							
							obj.find(o_grid+'.sortable-grid').each(function(){
								var subArr = [];
								$(this).children(o_widgetClass).each(function(){
									var subObj   = {};
									subObj['id'] = $(this).attr('id');
									subArr.push(subObj);
								});
								var out = {'section':subArr}
								mainArr.push(out);
							});	
								
							var storePositionObj = JSON.stringify( {'grid':mainArr} );
	
							/* Place it in the storage(only if needed) */
							if(getKeyPosition != storePositionObj){
								localStorage.setItem(keyPosition, storePositionObj); 
							}
						}
					}
			});		
		};
		
		/**
		* Default settings(dont change).
		* You can globally override these options
		* by using $.fn.pluginName.key = 'value';
		**/
		$.fn.powerWidgetsLite.options = {
			grid: '',
			widgets: '.powerwidget',
			localStorage: true,
			deleteSettingsKey: '',
			settingsKeyLabel: 'Reset settings?',
			deletePositionKey: '',
			positionKeyLabel: 'Reset position?',			
			sortable: true,
			buttonsHidden: false,
			toggleButton: true,
			toggleClass: 'min-10 | plus-10',
			toggleSpeed: 200,
			onToggle: function(){},
			opacity: 1.0,
			dragHandle: '> header',
			placeholderClass: 'powerwidget-placeholder',
			indicator: true,
			indicatorTime: 600,
			rtl: false			
		};
		
})(jQuery, window, document);
